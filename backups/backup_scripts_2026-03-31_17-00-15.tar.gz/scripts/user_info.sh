#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

LOG_DIR="$ROOT_DIR/logs"
LOG_FILE="$LOG_DIR/user_info.log"

mkdir -p "$LOG_DIR"

log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

read -rp "Enter your name: " name
read -rp "Enter your age: " age
read -rp "Enter your country: " country

if [[ -z "${name// }" || -z "${age// }" || -z "${country// }" ]]; then
  msg="Error: name, age, and country are required."
  echo "$msg"
  log "$msg"
  exit 1
fi

if ! [[ "$age" =~ ^[0-9]+$ ]]; then
  msg="Error: age must be numeric."
  echo "$msg"
  log "$msg"
  exit 1
fi

if [[ "$name" =~ ^[0-9]+$ ]]; then
  msg="Error: name cannot be numeric only."
  echo "$msg"
  log "$msg"
  exit 1
fi

if [[ "$country" =~ ^[0-9]+$ ]]; then
  msg="Error: country cannot be numeric only."
  echo "$msg"
  log "$msg"
  exit 1
fi

if (( age < 18 )); then
  category="Minor"
elif (( age <= 65 )); then
  category="Adult"
else
  category="Senior"
fi

message="Hello, $name from $country. You are $age years old and belong to the '$category' category."
echo "$message"
log "$message"
