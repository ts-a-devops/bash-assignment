#!/bin/bash
#
log_file="/home/eniiyi/bash-assignment/scripts/logs"
mkdir -p "$log_file"

timestamp=$(date +"%Y%m%d_%H%M%S")

backup="/home/eniiyi/bash-assignment/backups"

#make sure that directory backups exist
mkdir -p "$backup"

#create backup file path
backupfile="$backup/backup_$timestamp.tar.gz"

#read input form user
read -p "Enter a directory: " dir

#validate input as a directory
if [[ -d $dir ]]; then
	echo "valid directory"

#create compressed back up using "tar -c(create) z(.gz) f(file name flag) 
# "filename" "directory to be backed up"

	tar -czf "$backupfile" "$dir"
	echo""

	echo " "${dir}" Backup Created" | tee ${log_file/backups.log}

else echo "input a valid directory path"
fi
