#!/bin/bash


# Use echo to print "Hello, World!" and the current date (date command).
date=$(date +"%Y-%m-%d")
echo "Hello, World!" 
echo "Today's date is $date"

#  Add your name and hostname (hostname).
name="Hilda"
host=$(hostname)
echo "My name is $name and hostname is $host"

echo "My current working directory is:"
pwd

ls
