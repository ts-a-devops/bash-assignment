#!/bin/bash

# Declare variables: NAME="YourName", AGE=25, CONSTANT=42 (uppercase)
  
  NAME="" 
  AGE=25 
  CONSTANT=42
  SUM=$((AGE + 10))

  echo "Hello $NAME, you are $AGE years old."
  echo "The constant number is $CONSTANT"
  echo " $SUM "

# Bonus: Use parameter expansion ${NAME:-Default} for fallback.
  
  echo "Hello, ${NAME:-Default}"


