#!/bin/bash

# -e: Exit on error, -u: Error on undefined vars, -o pipefail: Error if pipe fails
set -euo pipefail

# Configuration
SCRIPT_DIR="."
LOG_FILE="logs/app.log"

# Create directories if they don't exist
mkdir -p "$SCRIPT_DIR" logs

# 2. Logic Functions
log_msg() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

run_script() {
    local script_name=$1
    local script_path="$SCRIPT_DIR/$script_name"

    if [[ -x "$script_path" ]]; then
        log_msg "Starting: $script_name"
        # 3. Handle failures without crashing the whole menu
        if "$script_path"; then
            log_msg "Completed: $script_name successfully."
        else
            log_msg "FAILED: $script_name returned an error."
        fi
    else
        echo "Error: $script_path not found or not executable."
        log_msg "ERROR: Missing $script_name"
    fi
}

# --- Interactive Menu ---

echo "========================================"
echo "    MASTER SCRIPT CONTROLLER"
echo "========================================"

PS3="Please select an option (1-4): "
options=("Run All" "System Check" "Backup" "Exit")

select opt in "${options[@]}"; do
    case $opt in
        "Run All")
            log_msg "User selected: RUN ALL"
            run_script "system_check.sh"
            run_script "backup.sh" "." # Backs up current dir
            ;;
        "System Check")
            run_script "system_check.sh"
            ;;
        "Backup")
            read -p "Enter directory to backup: " dir
            run_script "backup.sh" "$dir"
            ;;
        "Exit")
            log_msg "User exited Menu."
            echo "Goodbye!"
            break
            ;;
        *) 
            echo "Invalid option $REPLY. Try again."
            ;;
    esac
done
