sudo apt update && sudo apt upgrade
cd /mnt/
ls -al
cd c
ls -al
wsl --list --verbose
ls -al
ls
cd git_class
bash
git clone https://github.com/olakemmy/bash-assignment.git
cd devops-bash-toolkit
git clone https://github.com/olakemmy/bash-assignment.git devops-bash-toolkit
cd devops-bash-toolkit
git checkout -b feature/Ola-Oluwakemi
ls
git branch
mkdir scripts
ls
cd scripts
ls
user_info.sh system_check.sh file_manager.sh backup.sh process_monitor.sh 
touch user_info.sh system_check.sh file_manager.sh backup.sh process_monitor.sh 
ls
cd../
cd ../
ls
mkdir logs
ls
cd scripts
ls
cp user_info.sh ../devops-bash-toolkit/scripts/
cp user_info.sh ../ ../devops-bash-toolkit/scripts/
cp user_info.sh ../ ../bash-assignment/scripts/
cp user_info.sh ../devops-bash-toolkit/scripts
cp user_info.sh
cp --help
cp user_info.sh
user_info.sh
ls
cd ../
cd scripts
cd devops-bash-toolkit
cd home
ls
user
user_info.sh
cd../
ls
cp user_info.sh ../ ../bash-assignment/scripts/
cp user_info.sh ../bash-assignment/scripts/
cp user_info.sh ../ bash-assignment/scripts/
cp user_info.sh bash-assignment/scripts/
cd bash-assignment
ls
cd ../
ls
cd devops-bash-toolkit
script
ls
devops-bash-toolkit
cd devops-bash-toolkit
ls
cd scripts
ls
vi user_info.sh
ls
cd bas-assignment
cd bash-assignment
ls
scripts
cd scripts
ls
user_info
logs/user_info.log
ls
cd ../
ls
cd log
ls
vi user_info.sh
