#!/usr/bin/env bash

set -euo pipefail

LOG_DIR="logs"
LOG_FILE="$LOG_DIR/file_manager.log"

mkdir -p "$LOG_DIR"

log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

usage() {
  cat <<EOF
Usage:
  $0 create <filename>
  $0 delete <filename>
  $0 list [directory]
  $0 rename <old_name> <new_name>
EOF
  exit 1
}

[[ $# -ge 1 ]] || usage

command="$1"

case "$command" in
  create)
    [[ $# -eq 2 ]] || usage
    file="$2"

    if [[ -e "$file" ]]; then
      echo "Error: '$file' already exists."
      log "CREATE FAILED - '$file' already exists"
      exit 1
    fi

    touch "$file"
    echo "File '$file' created successfully."
    log "CREATED '$file'"
    ;;

  delete)
    [[ $# -eq 2 ]] || usage
    file="$2"

    if [[ ! -e "$file" ]]; then
      echo "Error: '$file' does not exist."
      log "DELETE FAILED - '$file' does not exist"
      exit 1
    fi

    rm -f "$file"
    echo "File '$file' deleted successfully."
    log "DELETED '$file'"
    ;;

  list)
    dir="${2:-.}"

    if [[ ! -d "$dir" ]]; then
      echo "Error: directory '$dir' does not exist."
      log "LIST FAILED - directory '$dir' does not exist"
      exit 1
    fi

    echo "Listing files in '$dir':"
    ls -lah "$dir"
    log "LISTED contents of '$dir'"
    ;;

  rename)
    [[ $# -eq 3 ]] || usage
    old_name="$2"
    new_name="$3"

    if [[ ! -e "$old_name" ]]; then
      echo "Error: '$old_name' does not exist."
      log "RENAME FAILED - '$old_name' does not exist"
      exit 1
    fi

    if [[ -e "$new_name" ]]; then
      echo "Error: '$new_name' already exists."
      log "RENAME FAILED - '$new_name' already exists"
      exit 1
    fi

    mv "$old_name" "$new_name"
    echo "Renamed '$old_name' to '$new_name'."
    log "RENAMED '$old_name' to '$new_name'"
    ;;

  *)
    usage
    ;;
esac
