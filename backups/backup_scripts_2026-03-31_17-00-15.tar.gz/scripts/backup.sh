#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

LOG_DIR="$ROOT_DIR/logs"
BACKUP_DIR="$ROOT_DIR/backups"
LOG_FILE="$LOG_DIR/backup.log"

mkdir -p "$LOG_DIR" "$BACKUP_DIR"

log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 <directory_to_backup>"
  log "BACKUP FAILED - invalid arguments"
  exit 1
fi

SOURCE_DIR="$1"

if [[ ! -d "$SOURCE_DIR" ]]; then
  echo "Error: directory '$SOURCE_DIR' does not exist."
  log "BACKUP FAILED - directory '$SOURCE_DIR' does not exist"
  exit 1
fi

TIMESTAMP="$(date '+%Y-%m-%d_%H-%M-%S')"
DIR_NAME="$(basename "$SOURCE_DIR")"
ARCHIVE_NAME="backup_${DIR_NAME}_${TIMESTAMP}.tar.gz"
ARCHIVE_PATH="$BACKUP_DIR/$ARCHIVE_NAME"

tar -czf "$ARCHIVE_PATH" "$SOURCE_DIR"

echo "Backup created: $ARCHIVE_PATH"
log "BACKUP CREATED - '$ARCHIVE_PATH' from '$SOURCE_DIR'"

backups=( $(ls -1t "$BACKUP_DIR"/backup_*.tar.gz 2>/dev/null || true) )

if (( ${#backups[@]} > 5 )); then
  for old_backup in "${backups[@]:5}"; do
    rm -f "$old_backup"
    echo "Deleted old backup: $old_backup"
    log "OLD BACKUP DELETED - '$old_backup'"
  done
fi
