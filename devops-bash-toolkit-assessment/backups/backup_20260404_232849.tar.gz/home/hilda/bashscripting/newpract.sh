#!/bin/bash

file="hil.txt"
dir="docs"

# use  -e/-a to check if file exist
if [[ -e $file ]]; then
    echo "$file exists"	
fi
# use  -f for regular file check  
if [[ -f $file ]]; then
    echo "$file is a regular file"
fi
# use  -d to check directory
if [[ -d $dir ]]; then
    echo "$dir is a directory"  
fi
# use  -s File exists and is not empty
if [[ -s $file ]]; then
    echo "$file exists and is not empty"
fi

