#!/bin/bash

echo "Why is the tower of Pisa leaning?"

read entered_name

echo -e "-\nCause it has better reflexes than the twin towers"
