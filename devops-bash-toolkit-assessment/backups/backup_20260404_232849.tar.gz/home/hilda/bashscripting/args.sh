#!/bin/bash

#  Print script name ($0), all args ($@), and count ($#)
scriptname="/args.sh"
allargs=(1 22 "DAN" 5 "KEN" "SARO" 8 "JANE" "LONDON")

echo "Script name: $0"
echo "All args: ${allargs[@]}"
echo "Count: ${#allargs[@]}"
# Require exactly 2 arguments (name and city); else print usage: "Usage: ./args.sh <name> <city>"

if [[ $# -ne 2 ]]; then
    echo "Usage: ./args.sh <name> <city>"
fi

# Print "Hello $1 from $2!".
# Assign arguments
name=$1
city=$2

# Print greeting
echo "Hello $name from $city!"

