#!/usr/bin/env bash

LOG_DIR="logs"
LOG_FILE="$LOG_DIR/user_info.log"

mkdir -p "$LOG_DIR"

timestamp() {
  date "+%Y-%m-%d %H:%M:%S"
}

log_message() {
  echo "[$(timestamp)] $1" >> "$LOG_FILE"
}

read -r -p "Enter your name: " name
read -r -p "Enter your age: " age
read -r -p "Enter your country: " country

if [[ -z "$name" || -z "$age" || -z "$country" ]]; then
  msg="Error: Name, age, and country are all required."
  echo "$msg"
  log_message "$msg"
  exit 1
fi

if ! [[ "$age" =~ ^[0-9]+$ ]]; then
  msg="Error: Age must be a numeric value."
  echo "$msg"
  log_message "$msg"
  exit 1
fi

if (( age < 18 )); then
  category="Minor"
elif (( age <= 65 )); then
  category="Adult"
else
  category="Senior"
fi

msg="Hello, $name from $country. You are $age years old and categorized as: $category."
echo "$msg"
log_message "$msg"
