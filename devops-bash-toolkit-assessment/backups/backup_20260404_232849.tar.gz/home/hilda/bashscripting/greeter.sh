#!/bin/bash

# Use read -p to ask for name and age
NAME="HILDA"
AGE=25
read -p "what is your name: " NAME
read -p "what is your age: " AGE
# Use read -s for a "password" (just echo it back safely).

read -s -p "what is your password: " password
# Greet the user with their input: "Welcome, $NAME! You are $AGE years old."
echo "Welcome, $NAME! You are $AGE years old."
#  Bonus: Validate age is a number (use conditional check).
if [[ "$AGE" =~ ^[0-9]+$ ]]
then
echo "$AGE is a number" 
fi

