#!/bin/bash
# scripts/process_monitor.sh
services=("nginx" "ssh" "docker")

for svc in "${services[@]}"; do
    if pgrep -x "$svc" > /dev/null; then
        echo "$svc: Running"
    else
        echo "$svc: Stopped. Attempting restart..."
        # Simulate restart
        echo "$svc: Restarted" >> logs/process_monitor.log
    fi
done