#!/bin/bash

script="file-exp.sh"

# -r: Readable
if [[ -r $script ]] ; then
    echo "$script is readable"
fi
# -w: writable
if [[ -w $script ]] ; then
    echo "$script is writable"
fi
# -x: Executable
if [[ ! -x $script ]] ; then
    echo "$script is not executable"
fi
# make file executable and try again
if [[ -x $script ]] ; then
    echo "$script is executable"
fi
# -c: special file
if [[  -c "/dev/kmsg" ]] ; then
    echo "/dev/kmsg is a character special file"
fi
