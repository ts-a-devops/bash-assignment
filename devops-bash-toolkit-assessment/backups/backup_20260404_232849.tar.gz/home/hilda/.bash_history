wsl --update
Set-ExecutionPolicy AllSigned
Set-ExecutionPolicyBypass-ScopeProcess-Force
wsl --list --verbose
wsl --install
wsl sudo_root
wsl --list --verbose
sudo apt install git -y
git --version
git clone git@github.com:onlydurodola/git_class.git
git@github.com:onlydurodola/git_class.git
https://github.com/HilRosie/git_class.git
git@github.com:onlydurodola/git_class.git
clear
git@github.com:onlydurodola/git_class.git
https://github.com/onlydurodola/git_class.git
https://github.com/HilRosie/git_class.git
clear
git init
git status
pwd
clean
clear
pwd
cd
cd ..
ls -la
ls -R
mkdir house
mkdir hil
pwd
sed 's/Devops/Devopsss/ 
pwd
mkdir training
mkdir tsa academy
ls
ls -l
touch devops.txt
touch learn.txt
cd
ls
ls -l
mkdir delete
ls
rmdir delete
ls -l
cd training
pwd
touch aws.txt
touch see.txt
ls
cd ..
pwd
rmdir training
rm -rf
rm -rf training
ls
mkdir love
mkdir prayers
touch novena
touch blessing
ls -l
ls -lr
ls -lt
ls ltr
ls -ltr
touch nti.txt
touch like.txt
ls -l
rm *.txt
ls
touch devops learn like nti know.txt
ls l
ls -l
ls -ltr
mv know.txt knows.txt
ls -l
mv learn.txt academy
mv knows.txt academy
ls -l
cat blessing
cat > blessing
cat blessing
cat > devops
cat >> devops
cat devops
cat -n devops
tac devops
cp blessing devops
cat devops
cat blessing
cat devops
cat >> devops
cat devops
cat >> devops
cat devops
tail devops
head -n 5 devops
history
cat >> devops
cat devops
grep "Devops" devops
grep -i "Devops" devops 
grep -v "Devops" devops
grep -c "Devops" devops
vi lovelike.txt
pwd
sed 's/Devops/Devopsss/
pwd
ls -l
sed 's/tsa/TSA' devops
sed -i 's/tsa/TSA/' devops
cat devops
vim devops
vi devops
vim devops
vi devops
cat devops
vi devops
cat devops
fg
jobs
[4]+  Stopped   vi devops
jobs [4]+  Stopped   vi devops
fg %4
jobs
kill %4
kill %3
kill %2
kill %1
vi devops
cat devops
sed -i '4d' devops
cat devops
sed -i '4i\TSA DevOps training begins!' devops
cat devops
vi devops
cat devops
sed -i '$a\DevOps training - way to go!' devops
cat devops
sed -i '$d\DevOps training - way to go!' devops
sed -i '$d' devops
cat devops
git -v
git --version
free
top
ls
ls -l
cat devops
cat learn
cat like
cd
cd love
pwd
touch luuvv protect empower.txt
ls
sudo zip *.txt
sudo zip allaboutlove *.txt
ls
vi love
rm luuvv protect empower.txt
ls
touch empower.txt
touch protect.txt
touch luuvv.txt
ls
ls -l
sudo zip allaboutlove *.txt
zip texts.zip *.txt
sudo apt install zip
zip texts.zip *.txt
ls -l
mv texts.zip allaboutlove.zip
ls-l
ls -l
sudo zip -sf allaboutlove.zip
unzip -l allaboutlove.zip
touch likee.txt
ls -l
sudo zip -r allaboutlove.zip likee.txt
sudo zip -sf allaboutlove.zip
zip -sf allaboutlove.zip
cd ..
pwd
ls -l
locate blessing
sudo apt install plocate
locate blessing
find blessing
sudo useradd hil
sudo passwd hil
ls -l
chmod u+x blessing
chmod o+w like
ls -l
chmod o-w like
ls -l
chmod 766 like
ls -l
chmod 400 nti
ls -l
sudo useradd -m hilrosie_home
groups
id
groupadd lih
sudo groupadd lih
whoami
lsof -u hil
ls -l
mv nti.txt ~/Trash/
mv nti ~/Trash/
ls *.txt
pwd
ls -l
cat devops
cd love
ls -l
ls *.txt
man ls
sudo apt update
apt list --upgradable
sudo apt upgrade
systemctl list-unit-files --type=service
2 mkdir-p ~/project/app/logs ~/project/config ~/project/scripts
history
pwd
mkdir-p ~/project/app/logs ~/project/config ~/project/scripts
mkdir -p ~/project/app/logs ~/project/config ~/project/scripts
ls
ls ~/project
cd projects
cd project
cd ..
tree ~/project
sudo apt  install tree
tree ~/project
ls -R ~/project
cd ~/project/app
ls -la
ls -la ../config/
ls -la config
ls -la ../config/
cp -r ~/project ~/project-backup-$(date +%Y%m%d)

cat > ~/deploy.sh << 'EOF'
#!/bin/bash
echo "=== Deployment Started at $(date) ==="
echo "This script would:"
echo "1. Pull latest code from Git"
echo "2. Run database migrations"
echo "3. Restart services"
echo "4. Notify Slack channel"
echo "=== Deployment Complete ==="
EOF

pwd
tree ~/project
cd ..
pwd
tree ~/project
ls -la
chmod +x ~/deploy.sh
./deploy.sh
ls -la ~/deploy.sh
./deploy.sh
sudo ./deploy.sh
sudo chown $USER:$USER ~/deploy.sh
hostname
history
timedatectl
pkill ping
ping 8.8.8.8 > /dev/null &
jobs
ps aux | grep ping
jobs
pgrep ping
jobs
ping 8.8.8.8 > /dev/null
jobs
ping 8.8.8.8 > /dev/null &
jobs
kill -9 $PID
jobs
pgrep ping || echo "Process terminated successfully"
pkill ping
pgrep ping || echo "Process terminated successfully"
sudo apt update
sudo apt install nginx-y
sudo apt install nginx -y
curl localhost
curl-I http://127.0.0.1
curl -I http://127.0.0.1
sudo sysyemctl start nginx
sudo systemctl start nginx
ip a
ip route
ss-tuln
ss -tuln
ping-c 4 google.com
ping-c 4 github.com
ping-c 4 8.8.8.8
ping -c 4 google.com
ping -c 4 github.com
ping -c 4 8.8.8.8
curl -O https://httpbin.org/robots.txt
ls -la robots.txt
rm robots.txt
curl -O https://httpbin.org/robots.txt
ls -la robots.txt
rm robots.txt
nmap localhost
sudo netstat -tlnp 2>/dev/null || sudo ss -tlnp
nc -zv localhost 80 2>/dev/null || echo "port 80 not accessible"
nc -zv localhost 80 || echo "port 80 not accessible"
nc -zv localhost 80 2>/dev/null || echo "port 80 not accessible"
sudo passwd devops1 # Set password: devops123
sudo useradd -m -G sudo useradd-m-G developers-s /bin/bash developer2
sudo passwd developer2 # Set password: dev123
id devops1
groups devops1
ls -ld /home/dev*
su - devops1
su - developer2
mkdir -p /opt/team-project
sudo mkdir -p /opt/team-project
tree ~/opt/
tree ~/opt/team-project
pwd
sudo mkdir -p /opt/team-project
hil
su - devops1 -c "touch /opt/team-project/test.txt"
sudo userdel-r devops1
sudo userdel -r devops1
ls -ld /opt/team-project
sudo ls -la /var/log/auth.log*
sudo tail -f /var/log/syslog &
sudo grep -i "fail" /var/log/auth.log | tail -10
jobs
pkill tail
jobs
sudo pkill tail
jobs
sudo apt install nmap -y
sudo apt delete nmap -y
sudo apt delete nmap
sudo apt remove nmap -y
sudo apt install nmap -y
sudo groupadd ifyy
sudo useradd -m -G ifyy -s/bin/bash onyem
id onyem
groups onyem
su onyem
sudo passwd onyem   # Set password: dev123
sudo journalctl -u cron -f   # Press Ctrl+C to stop
sudo journalctl -u cron -f   
jobs
cat > /tmp/app.log << 'EOF'
2025-01-15 10:30:15 ERROR Database connection failed
2025-01-15 10:30:16 INFO User login successful
2025-01-15 10:30:17 WARN Slow query detected
2025-01-15 10:30:18 ERROR Payment gateway timeout
2025-01-15 10:30:19 INFO Cache hit ratio: 85%
EOF

grep ERROR /tmp/app.log
# 1. Create application configuration
cat > ~/app.conf << 'EOF'
# Production Configuration
APP_ENV=production
APP_PORT=8000
DB_HOST=localhost
DB_PORT=5432
DB_NAME=app_production
DB_USER=app_user
DB_PASS=secret123
DEBUG=false
LOG_LEVEL=info
EOF

cat > ~/app.conf << 'EOF'
# Production Configuration
APP_ENV=production
APP_PORT=8000
DB_HOST=localhost
DB_PORT=5432
DB_NAME=app_production
DB_USER=app_user
DB_PASS=secret123
DEBUG=false
LOG_LEVEL=info
EOF

vim ~/app.conf
pwd
df -h / /home
df -i /
free -h
cat /proc/meminfo | grep -E "(MemTotal|MemFree|MemAvailable)"
swapon --show
top
sudo apt install htop -y
htop
du -sh ~/*
du -sh /var | sort -rh | head -10
sudo find /var/log -type f -size +100M -exec ls -lh {} \;
uptime
vmstat 1 5
iostat -x 1 3
sudo apt install sysstat
iostat -x 1 3
sudo apt update
sudo mkdir -p /var/www/mysite/{html,logs,backup}
cat > /tmp/index.html << ’EOF’
<!DOCTYPE html>
<html>
<head>
<title>DevOps Demo Site</title>
<style>
body { font-family: Arial; margin: 40px; background: #1e1e1e;
color: #fff; }
container { max-width: 800px; margin: 0 auto; }
status { background: #2d2d2d; padding: 20px; border-radius:
5px; }
</style>
</head>
<body>
<div class="container">
<h1> DevOps Demo Site</h1>
<div class="status">
<p><strong>Server:</strong> $(hostname)</p>
<p><strong>Deployed by:</strong> $(whoami)</p>
<p><strong>Deployed at:</strong> $(date)</p>
<p><strong>Status:</strong> <span style="color:
#4CAF50"> Live</span></p>
</div>
<h2>Production Ready Features:</h2>
<ul>
<li>Automated deployment pipeline</li>
<li>Log monitoring and alerting</li>                                                                        li>CDN integration ready</li>                                                                           m   


cat << 'EOF' > /tmp/index.html
<!DOCTYPE html>
<html>
<head>
<title>DevOps Demo Site</title>
<style>
body { font-family: Arial; margin: 40px; background: #1e1e1e; color: #fff; }
.container { max-width: 800px; margin: 0 auto; }
.status { background: #2d2d2d; padding: 20px; border-radius: 5px; }
</style>
</head>
<body>
<div class="container">
<h1> DevOps Demo Site</h1>
<div class="status">
<p><strong>Server:</strong> $(hostname)</p>
<p><strong>Deployed by:</strong> $(whoami)</p>
<p><strong>Deployed at:</strong> $(date)</p>
<p><strong>Status:</strong> <span style="color:#4CAF50"> Live</span></p>
</div>
<h2>Production Ready Features:</h2>
<ul>
<li>Automated deployment pipeline</li>
<li>Log monitoring and alerting</li>
<li>SSL certificate (coming soon)</li>
<li>CDN integration ready</li>
</ul>
</div> </html>
</body>
</html>
EOF

sudo tee /etc/nginx/sites-available/mysite << 'EOF'
server {
    listen 80;
    server_name _;

    root /var/www/mysite/html;
    index index.html;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;

    # Logging
    access_log /var/www/mysite/logs/access.log;
    error_log  /var/www/mysite/logs/error.log;

    location / {
        try_files $uri $uri/ =404;

        # Cache static files
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
EOF

sudo ln -s /etc/nginx/sites-available/mysite /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default
git --version
git init
git status
mkdir my-history-repo
git init
cat > index.html << 'EOF'
random quotes
1. "The only way to do great work is to love what you do." – Steve Jobs
2. "You miss 100% of the shots you don't take." – Wayne Gretzky
3. "Life is what happens when you're busy making other plans." – John Lennon
4. "Success is not the key to happiness. Happiness is the key to success." – Albert
EOF

git add .
git commit -m "Initial commit"
git config --global user.name "HilRosie"
git commit -m "Initial commit"
vim index.html
jobs
fg
git add .
git commit -m "Added header section"
git log
git log --oneline
git remote add origin https://github.com/HilRosie/mytraining.git
git push -u origin main
git branch
git branch -m master main
git branch
git remote add origin https://github.com/HilRosie/mytraining.git
git push -u origin main
git remote -v
git remote add origin git@github.com:HilRosie/mytraining.git
git push -u origin main
ssh-keygen -t ed25519 -C "sinecera777@gmail.com"
ls .ssh/
cat ~/.ssh/id_ed25519
cat ~/.ssh/id_ed25519.pub
eval "$(ss -agent -s)"
eval "$(ssh -agent -s)"
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519
ssh -T git@github.com
git remote -v
git remote set-url origin git@github.com:HilRosie/mytraining.git
git remote -v
git push -u origin main
ls ~/.ssh/
git switch -c feat/HilR
git branch
git checkout main
git pull origin main
git log
pwd
ls
vim greeter
vim greeter.sh
./greeter.sh
vim greeter.sh
PWD
pwd
touch variables.sh
vim variables.sh
chmod +x variables.sh
./variables.sh
vim variables.sh
bash variables.sh
vim variables.sh
./variables.sh
unset NAME
./variables.sh
vim variales.sh
jobs
vim variables.sh
./variables.sh
vim variables.sh
./variables.sh
vim variables.sh
bash variables.sh
vim variables.sh
./variables.sh
vim variables.sh
./variables.sh
touch greeter.sh
vim greeter.sh
./variables.sh
chmod +x greeter.sh
./greeter.sh
vim greeter.sh
./greeter.sh
vim greeter.sh
git status
git clone git@github.com:HilRosie/git_class.git
cd git_class
ls
cat > practice << 'EOF'
I was here
EOF

git add .
git pull origin main
git push origin main
ls
vim practice
git add .
git commit -m "new practice"
git pull origin main
git push origin main-u origin practice
git push -u origin main
git checkout main
git branch
git switch
cd ..
git switch -C feat/hil
git log --graph
pwd
touch hello.sh
vim hello.sh
chmod +x hello.sh
./hello.sh
bash hello.sh
vim hello sh
vim hello.sh
./hello.sh
vim hello.sh
./hello.sh
vim hello.sh
./hello.sh
vim hello.sh
bash hello.sh
vim hello.sh
bash hello.sh
vim hello.sh
echo $SHELL
which bash
vim hello.sh
bash hello.sh
pwd
ls
vim greeter.sh
./greeter.sh
vim greeter.sh
./greeter.sh
vim greeter.sh
./greeter.sh
vim greeter.sh
./greeter.sh
mkdir ifstatement
ls
mv variables.sh ifstatement
mv greeter.sh ifstatement
mv variales.sh args.sh 
ls
cat args.sh
cat ifstatement
cd ifstatement
ls
cd ..
mv args.sh ifstatement
ls
cd ifstatement
vim args.sh
./args.sh
chmod +x args.sh
./args.sh
vim args.sh
./args.sh
vim args.sh
./args.sh
vim args.sh
./args.sh
vim args.sh
./args.sh
vim args.sh
./args.sh
vim args.sh
cat args.sh
vim args.sh
./args.sh
vim args.sh
./args.sh
cat args.sh
vim args.sh
./args.sh
vim args.sh
./args.sh
./args.sh DAN LONDON
./args.sh
./args.sh DAN LONDON
cd ..
mv ifstatement bashscripting
ls
cd bashscripting
ls
cd /dev/
ls
ls -l
cd ..
pwd
man
ls
cd bashscripting
vim newpract.sh
mkdir docs
touch hil.txt
vim newpract.sh
./newpract.sh
chmod +x newpract.sh
./newpract.sh
vim newpract.sh
./newpract.sh
vim hil.txt
./newpract.sh
vim file-exp.sh
chmod +x file-exp.sh
./file-exp.sh
vim file-exp.sh
./file-exp.sh
vim file-exp.sh
./file-exp.sh
vim file-exp.sh
./file-exp.sh
vim file-exp.sh
./file-exp.sh
vim file-exp.sh
chmod 744 "$script"
chmod 744 file-exp.sh
./file-exp.sh
git init
git branch
git status
cd ..
git branch
git status
git branch
git checkout main
git status
git branch
ls
cat bash-assignment
ls -la
cd bash-assignment
ls -la
cat git
cat .git
cd .git
ls
cd ..
mkdir devops-bash-toolkit-assessment
cd devops-bash-toolkit-assessment
mkdir scripts/
touch user_info.sh
tree ~/devops-bash-toolkit-assessment
ls devops-bash-toolkit-assessment
tree ~/bash-assignment
ls
touch system_check.sh
mv system_check.sh scripts/
touch user_info.sh
mv user_info.sh scripts/

tree ~/devops-bash-toolkit-assessment
touch scripts/file_manager.sh
touch scripts/backup.sh
touch scripts/process_monitor.sh
tree ~/bash-assignment
touch run_all.sh
touch README.md
ls-l
;s -l
ls -l
cd ..
tree ~/devops-bash-toolkit-assessment
tree ~/bash-assignment
cd devops-bash-toolkit
cd devops-bash-toolkit-assessment
tree
git checkout main
git checkout -b feature/bash-Hilda
git branch
vim user_info.sh
chmod +x user_info.sh
bash user_info.sh
vim user_info.sh
bash user_info.sh
vim user_info.sh
bash user_info.sh
vim user_info.sh
bash user_info.sh
vim user_info.sh
vim system_check.sh
ls
cd bash-assignment
cd scripts
ls
cd devops-bash-toolkit-assessment
cd scripts
vim system_check.sh
jobs
cat system_check.sh
bash system_check.sh
cat system_check.sh
vim system_check.sh
bash system_check.sh
cat system_check.sh
vim system_check.sh
bash system_check.sh
vim system_check.sh
bash system_check.sh
vim system_check.sh
ls
mkdir -p logs
ls
vim user_info.sh
bash user_info.sh
ls
cat user_info.sh
vim user_info.sh
bash user_info.sh
vim user_info.sh
bash user_info.sh
vim user_info.sh
bash user_info.sh
ls
vim system_check.sh
bash system_check.sh
vim system_check.sh
bash system_check.sh
vim system_check.sh
bash system_check.sh
vim user_info.sh
vim system_check.sh
bash system_check.sh
vim system_check.sh
ls
vim file_manager.sh
chmod +x file_manager.sh
./file_manager.sh
vim file_manager.sh
./file_manager.sh
ls
tree ~/scrpts
tree ~/bash_assignment
tree ~/bash-assignment
mv file.txt file_manager.sh
tree ~/bash-assignment
ls file_manager.sh
cat file.txt
cat file_manager
cat file_manager.sh
tree ~/scripts
vim file_manager.sh
cp file_manager.sh file.txt
ls
cat file.txt
vim file.txt
vim file_manager.sh
rm file.txt
vim file_manager.sh
bash file_manager.sh
cat file_manager.sh
ls
cat filenew.txt
cat file_manager.sh
vim file_manager.sh
