#!/bin/bash
echo "Will you be my boyfriend? "
read statement

if [ "$statement" = "yes" ]; then
	  echo -e "\n\t\t\tYay! I love you"
  elif [ "$statement" = "no" ]; then
	    echo -e "\n\t\t\tWhy motherfucker?"
    else
	      echo -e "\n\t\t\tThat's not an answer, I need a yes or no."
fi

for i in {1..10}
do
	echo $i
done

i=2
while [[ $i -le 20 ]] ; do
	echo "$i"
(( i += 1 ))
done

fruit="mangi"

case $fruit in
	"apple")
	 echo "This is a red fruit."
  	 ;;
	 "banana")
	 echo "This is a yellow fruit."
         ;;
	 "orange")								        echo "This is an orange fruit."
		 ;;
	 *)
	 echo "Unknown fruit."
	 ;;
	esac
