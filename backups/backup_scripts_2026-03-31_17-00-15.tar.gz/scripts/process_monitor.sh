#!/usr/bin/env bash

set -euo pipefail

LOG_DIR="logs"
LOG_FILE="$LOG_DIR/process_monitor.log"

mkdir -p "$LOG_DIR"

services=("nginx" "ssh" "docker")

log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 <process_name>"
  echo "Supported services: ${services[*]}"
  exit 1
fi

process_name="$1"
supported=false

for service in "${services[@]}"; do
  if [[ "$service" == "$process_name" ]]; then
    supported=true
    break
  fi
done

if [[ "$supported" == false ]]; then
  echo "Service '$process_name' is not in monitored list: ${services[*]}"
  log "UNSUPPORTED SERVICE - '$process_name'"
  exit 1
fi

if pgrep -x "$process_name" >/dev/null 2>&1; then
  echo "Running"
  log "SERVICE '$process_name' STATUS: Running"
else
  echo "Stopped"
  log "SERVICE '$process_name' STATUS: Stopped"

  if command -v systemctl >/dev/null 2>&1; then
    if sudo systemctl restart "$process_name" 2>/dev/null; then
      echo "Restarted"
      log "SERVICE '$process_name' STATUS: Restarted"
    else
      echo "Restart simulation failed or permission denied for '$process_name'"
      log "SERVICE '$process_name' RESTART FAILED OR SIMULATED"
    fi
  else
    echo "Restarted (simulated)"
    log "SERVICE '$process_name' STATUS: Restarted (simulated)"
  fi
fi
