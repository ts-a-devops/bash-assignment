#!/bin/bash

echo "What's your name sweetheart?"

read entered_name

echo -e "\n\t\t\t\tWelcome to bash tutorial" $entered_name

echo -e "\n\t\tI know this might be a bit hard but you can do it.\n\t\t\t\t I love you" $entered_name.

