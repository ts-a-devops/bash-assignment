#!/usr/bin/env bash

LOG_DIR="logs"
DATE_STAMP="$(date +%Y%m%d_%H%M%S)"
LOG_FILE="$LOG_DIR/system_report_${DATE_STAMP}.log"

mkdir -p "$LOG_DIR"

{
  echo "System Check Report - $(date)"
  echo "========================================"
  echo

  echo "[Disk Usage]"
  df -h
  echo

  echo "[Memory Usage]"
  if command -v free >/dev/null 2>&1; then
    free -m
  else
    vm_stat
  fi
  echo

  echo "[CPU Load]"
  uptime
  echo

  echo "[Disk Usage Warnings (>80%)]"
  # Parse df output and report mounted filesystems above threshold.
  df -P | awk 'NR>1 {gsub(/%/,"",$5); if ($5 > 80) printf "WARNING: %s is at %s%% usage (mount: %s)\\n", $1, $5, $6}'
  echo

  echo "[Total Running Processes]"
  ps -e | wc -l | awk '{print $1 - 1}'
  echo

  echo "[Top 5 Memory-Consuming Processes]"
  ps -Ao pid,comm,%mem --sort=-%mem | head -n 6
} | tee "$LOG_FILE"
