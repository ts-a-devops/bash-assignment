#!/bin/bash

LOG_FILE="../logs/file_manager.log"

COMMAND=$1
FILENAME=$2
case ${COMMAND} in
    "create")
	    if [ -f "${FILENAME}" ]; then
		    echo "Error: ${FILENAME} already exists!" | tee -a "${LOG_FILE}"
	    else
		    touch "${FILENAME}"
		    echo "Created file: ${FILENAME}" | tee -a "${LOG_FILE}"
	    fi
	    ;;
    "delete")
	    if [ ! -f "${FILENAME}" ]; then
		    echo "Error: ${FILENAME} does not exist!" | tee -a "${LOG_FILE}"
	    else
		    rm "${FILENAME}"
		    echo "Deleted file: ${FILENAME}" | tee -a "${LOG_FILE}"
	    fi
	    ;;
    "list")
	    ls -F | tee -a "${LOG_FILE}"
	    ;;
    "rename")
	    NEWNAME=$3
	    if [ ! -f "${FILENAME}" ]; then
		    echo "Error: ${FILENAME} does not exist!" | tee -a "${LOG_FILE}"
	    elif [ -z "${NEWNAME}" ]; then
		    echo "Error: new name not provided!" | tee -a "${LOG_FILE}"
	    else
		    mv "${FILENAME}" "${NEWNAME}"
		    echo "Renamed ${FILENAME} to ${NEWNAME}" | tee -a "${LOG_FILE}"
	    fi
	    ;;
esac
